# This files contains your custom actions which can be used to run
# custom Python code.
#
# See this guide on how to implement these action:
# https://rasa.com/docs/rasa/custom-actions


# This is a simple example for a custom action which utters "Hello World!"

from typing import Any, Text, Dict, List
import os


from rasa_sdk import Action, Tracker
from rasa_sdk.executor import CollectingDispatcher
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.preprocessing import LabelEncoder, StandardScaler
from rasa_sdk.events import SlotSet

#
#
# class ActionHelloWorld(Action):
#
#     def name(self) -> Text:
#         return "action_hello_world"
#
#     def run(self, dispatcher: CollectingDispatcher,
#             tracker: Tracker,
#             domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:
#
#         dispatcher.utter_message(text="Hello World!")
#
#         return []
class ActionShowImage1(Action):
    def name(self) -> str:
        return "action_show_image1"
    def run(self, dispatcher: CollectingDispatcher,
            tracker: Tracker,
            domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:

        image_path = os.path.join("static", "images", "mean_likes50_per_secteur.png")

        # Ensure the image_path is correct and accessible on your local machine

        # Displaying the image
        dispatcher.utter_message(text="Here's the statistics image.I can't visualize all  sectors but here you can found 50 sectors ", image=image_path)

        return []
class ActionShowImage2(Action):
     def name(self) -> str:
        return "action_show_image2"
     def run(self, dispatcher: CollectingDispatcher,
            tracker: Tracker,
            domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:

    
        image_path = os.path.join("static", "images", "histogram_of_likes.png")

        
        dispatcher.utter_message(text=" Yes , of course .Here is the photo. ", image=image_path)

        return []
class ActionShowImage3(Action):
    def name(self) -> str:
        return "action_show_image3"

    def run(self, dispatcher: CollectingDispatcher,
            tracker: Tracker,
            domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:

        # Chemins vers vos images
        image_path1 = os.path.join("static","images","Regression.png")
        image_path2 = os.path.join("static","images","Regression1.png")

        # Envoi de la première image
        dispatcher.utter_message(text="Here is the first version of the figure:", image=image_path1)
    
        # Envoi de la deuxième image
        dispatcher.utter_message(text="Here is the second version of the figure:", image=image_path2)

        # Les chemins suivants semblent être des fichiers Excel, pas des images
        excel_path1 = os.path.join("static","images","lespepitestech(1).png")
        excel_path2 = os.path.join("static","images","les petipes2.png")
        
        # Si ce sont des images, utilisez `image`, sinon, vous devrez gérer les fichiers Excel différemment
        dispatcher.utter_message(text="Here is the first Excel-like image:", image=excel_path1)
        dispatcher.utter_message(text="Here is the second Excel-like image:", image=excel_path2)
        
        return []
class ActionPredictLikes(Action):


    def name(self) -> str:
        return "action_predict_likes"

    def run(self, dispatcher: CollectingDispatcher, tracker: Tracker, domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:
        df1 = pd.read_excel("C:\\Users\\21697\\OneDrive\\Bureau\\AI\\stage formation humaine\\lespepitestech_correspandancefinal.xlsx")  # Load your data
        x = df1.iloc[:, 1].values.reshape(-1, 1)
        y = df1.iloc[:, 4].values.reshape(-1, 1)

        secteur_input = tracker.get_slot('secteur')   
        l=secteur_input.split()
        secteur_input=l[len(l)-1]
          
       

        dispatcher.utter_message(text=f"Searching for sector: {secteur_input}")


# Filtrer le DataFrame pour trouver la ligne correspondant au secteur spécifié
# Supposons que 'Secteur' est la colonne contenant les noms des secteurs
        try:
          row = df1[df1['Secteur'].str.strip().str.contains(secteur_input)]

          prediction = row.iloc[0]['NB_JAIME']
          dispatcher.utter_message(text=f"The predicted likes for the sector {secteur_input} is {prediction}")


# Vérifier si une ligne a été trouvée et extraire la prédiction
        except:
            x=x.reshape(1622,)
            x_str = ','.join(x)
            dispatcher.utter_message(text="The sector searched not found .Please chose an other one. chose one through "+x_str) 

        
        
        # Send the prediction back to the user

        return []
class ActionPredictHighLikes(Action):


    def name(self) -> str:
        return "action_predict_high_likes"

    def run(self, dispatcher: CollectingDispatcher, tracker: Tracker, domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:
        df1 = pd.read_excel("C:\\Users\\21697\\OneDrive\\Bureau\\AI\\stage formation humaine\\lespepitestech_correspandancefinal.xlsx")  # Load your data
        max_likes = df1['NB_JAIME'].max()

# Filter the DataFrame to get rows where 'NB_JAIME' equals the maximum value
        rows_with_max_likes = df1[df1['NB_JAIME'] == max_likes]
        c=rows_with_max_likes.iloc[0]['Secteur']
        dispatcher.utter_message(text="The sector most liked is " + c)

        return []
    